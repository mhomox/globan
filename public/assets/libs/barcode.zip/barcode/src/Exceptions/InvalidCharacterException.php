<?php

namespace Picqer\Barcode\Exceptions;

class InvalidCharacterException extends BarcodeException {}